/*CMD
  command: /options
  help: 
  need_reply: 
  auto_retry_time: 
  folder: ⚙ Options
  answer: 
  keyboard: 
  aliases: ⚙ Options
CMD*/

Bot.sendInlineKeyboard(
  LANG.options.inlineButtons,
  LANG.options.text
)