/*CMD
  command: @
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Common
  answer: 
  keyboard: 
  aliases: 
CMD*/

if(user){
  LANG = Libs.Lang.get();
}

Base = Libs.Base;