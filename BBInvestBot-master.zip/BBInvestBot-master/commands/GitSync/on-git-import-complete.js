/*CMD
  command: on-git-import-complete
  help: 
  need_reply: 
  auto_retry_time: 
  folder: GitSync
  answer: Git import completed. Setup is runned
  keyboard: 
  aliases: 
CMD*/

Bot.runCommand("/setup");