/*CMD
  command: on-ipn
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Deposit
  answer: 
  keyboard: 
  aliases:
CMD*/

var coin = params;
Bot.sendMessage("IPN:")
Bot.sendMessage(inspect(options));